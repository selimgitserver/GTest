/*
 * operations.cpp
 *
 *  Created on: 11 Ara 2014
 *      Author: selim
 */

float add(float x, float y){return x+y;}
float sub(float x, float y){return x-y;}
float mul(float x, float y){return x*y;}
float divv(float x, float y){return x/y;}


