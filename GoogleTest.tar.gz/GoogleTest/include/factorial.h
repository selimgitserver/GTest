/*
 * factorial.h
 *
 *  Created on: 11 Ara 2014
 *      Author: selim
 */

#ifndef FACTORIAL_H_
#define FACTORIAL_H_


int factorial(int n);


#endif /* FACTORIAL_H_ */
