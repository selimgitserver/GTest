/*
 * operations.h
 *
 *  Created on: 11 Ara 2014
 *      Author: selim
 */

#ifndef OPERATIONS_H_
#define OPERATIONS_H_


float add(float x, float y);
float sub(float x, float y);
float mul(float x, float y);
float divv(float x, float y);


#endif /* OPERATIONS_H_ */
